package com.restApiSQL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiSqlApplication.class, args);
	}

}
